from project.dog import Dog

dog = Dog()
print(dog.bark())
print(dog.eat())
