from project.fruit import Fruit

a = Fruit("apple", "2024-02-06")
b = Fruit("banana", "2023-12-25")

print(a.name)
print(a.expiration_date)
print(b.name)
print(b.expiration_date)
